document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("login-form");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");
    const emailError = document.getElementById("email-error");
    const passwordError = document.getElementById("password-error");

    loginForm.addEventListener("submit", function (event) {
        event.preventDefault();
        emailError.textContent = "";
        passwordError.textContent = "";

        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();

        if (validateEmail(email) && validateInput(password)) {
            if (email === "admin@example.com" && password === "password") {
                alert("Logged in successfully!");
                // Redirect to another page or perform any other action upon successful login
            } else {
                showError(emailError, "Invalid email or password!");
            }
        } else {
            if (!validateEmail(email)) {
                showError(emailError, "Invalid email!");
            }
            if (!validateInput(password)) {
                showError(passwordError, "Invalid password!");
            }
        }
    });

    function validateEmail(email) {
        const emailRegex = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;
        return emailRegex.test(email);
    }

    function validateInput(input) {
        return input.length > 0;
    }

    function showError(element, message) {
        element.textContent = message;
    }
});