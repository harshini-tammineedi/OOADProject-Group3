package login.bean;

public class Menu {
	    private Integer menuid;
	    private String item;
	    private Float price;
	    private String status;

	    public Integer getMenuid() {
	        return menuid;
	    }

	    public void setMenuid(Integer menuid) {
	        this.menuid = menuid;
	    }

	    public String getItem() {
	        return item;
	    }

	    public void setitem(String item) {
	        this.item = item;
	    }
	    
	    public Float getPrice() {
	        return price;
	    }

	    public void setPrice(Float price) {
	        this.price = price;
	    }
	    
	    public String getStatus() {
	        return status;
	    }

	    public void setStatus(String status) {
	        this.status = status;
	    }

}
