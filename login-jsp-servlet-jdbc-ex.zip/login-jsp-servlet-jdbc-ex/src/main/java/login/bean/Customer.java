package login.bean;

public class Customer {
	private String firstName;
    private String lastName;
    private String email;
    private String phone;
    
    public Customer() {}
    
    public Customer(String fname, String lname, String email, String phone) {
        super();
        this.firstName = fname;
        this.lastName = lname;
        this.email = email;
        this.phone = phone;
    }
    
    public String getfirstName() {
        return firstName;
    }

    public void setfirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getlastName() {
        return lastName;
    }

    public void setlastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getemail() {
        return email;
    }

    public void setemail(String email) {
        this.email = email;
    }
    
    public String getphone() {
        return phone;
    }

    public void setphone(String phone) {
        this.phone = phone;
    }

}
