package login.bean;

public class Table {
	private Integer tableid;
    private Integer maxcapacity;
    private String status;

    public Integer getTableid() {
        return tableid;
    }

    public void setTableid(Integer tableid) {
        this.tableid = tableid;
    }

    public Integer getMaxcapacity() {
        return maxcapacity;
    }

    public void setMaxcapacity(Integer  maxcapacity) {
        this. maxcapacity =  maxcapacity;
    }
    
    
    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
