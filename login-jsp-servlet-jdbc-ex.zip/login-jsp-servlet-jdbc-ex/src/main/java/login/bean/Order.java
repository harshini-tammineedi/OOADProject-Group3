package login.bean;

public class Order {
	private Integer tablenumber;
    private Integer ordernumber;
	private Integer reservationnumber;
	private Integer quantity;
    private String status;
	private String item;
	
public Order() {}
    
    public Order(Integer ordernumber, Integer reservationnumber, Integer tablenumber, String item, Integer quantity, String St) {
        super();
        this.tablenumber = tablenumber;
        this.ordernumber = ordernumber;
        this.item = item;
        this.quantity = quantity;
       
        this.reservationnumber = reservationnumber;
        this.status = St;
    }

    public Integer getTablenumber() {
        return tablenumber;
    }

    public void setTablenumber(Integer tablenumber) {
        this.tablenumber = tablenumber;
    }
	public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
	
	
    
	public Integer getOrdernumber() {
        return ordernumber;
    }

    public void setOrdernumber(Integer ordernumber) {
        this.ordernumber = ordernumber;
    }

    public Integer getReservationnumber() {
        return reservationnumber;
    }

    public void setReservationnumber(Integer reservationnumber) {
        this.reservationnumber =  reservationnumber;
    }
	public String getItem() {
        return item;
    }
	
	public void setItem(String item) {
		this.item = item;
	}
    
    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
