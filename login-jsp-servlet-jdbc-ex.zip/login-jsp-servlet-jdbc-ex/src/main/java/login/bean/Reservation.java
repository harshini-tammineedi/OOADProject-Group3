package login.bean;

import java.util.Date;

public class Reservation {
	private Integer tableid;
    private Integer reservationnumber;
	private String dateofreservation;
	private Integer numberofpeople;
    private String email;
    
public Reservation() {}
    
    public Reservation(Integer tableid, Integer reservationnumber, String email, String dateofreservation, Integer numberofpeople) {
        super();
        this.tableid = tableid;
        this.reservationnumber = reservationnumber;
        this.email = email;
        this.dateofreservation = dateofreservation;
        this.numberofpeople = numberofpeople;
    }
	

    public Integer getTableid() {
        return tableid;
    }

    public void setTableid(Integer tableid) {
        this.tableid = tableid;
    }
	public String getDateofreservation() {
        return dateofreservation;
    }
	
	public void setDateofreservation(String dateofreservation) {
		this.dateofreservation = dateofreservation;
	}
	
	public Integer getNumberofpeople() {
        return numberofpeople;
    }

    public void setNumberofpeople(Integer numberofpeople) {
        this.numberofpeople = numberofpeople;
    }

    public Integer getReservationnumber() {
        return reservationnumber;
    }

    public void setReservationnumber(Integer  reservationnumber) {
        this. reservationnumber =  reservationnumber;
    }
    
    
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
    	this.email=email;
    }

}
