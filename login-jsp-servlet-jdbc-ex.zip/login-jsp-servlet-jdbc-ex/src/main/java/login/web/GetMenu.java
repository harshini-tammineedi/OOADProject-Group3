package login.web;

import java.io.*;
import java.sql.*;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.util.*;

import login.database.DatabaseConnection;
import login.bean.Menu;

/**
 * Servlet implementation class GetMenu
 */
@WebServlet("/GetMenu")
public class GetMenu extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetMenu() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				PrintWriter out = response.getWriter();  
				ArrayList<Menu> menuItems = new ArrayList<Menu>();
		        System.out.println("GetMenu Servlet");
		        try 
		        {   
		        	Connection con = DatabaseConnection.initializeDatabase();
		        	
		            PreparedStatement ps = con.prepareStatement ("select * from Menu");
		            
		            ResultSet rs = ps.executeQuery ();
		             /* Printing result */
		            while (rs.next ())
		           {
		            	Menu m = new Menu();
		            	m.setMenuid(rs.getInt("MenuId"));
		            	m.setitem(rs.getString("Item"));
		            	m.setPrice(rs.getFloat("Price"));
		            	m.setStatus(rs.getString("Status"));  
		            	menuItems.add(m);
		            	System.out.println("Menu--"+m);
		           }
		           con.close();  
		         } catch (Exception e) 
		           {  
		            out.println("error");  
		           } 
		         request.setAttribute("menuItems", menuItems);
		         
		         RequestDispatcher dispatcher = request.getRequestDispatcher("MenuList.jsp");
		         
		         dispatcher.forward(request, response);


		
	}

	

}
