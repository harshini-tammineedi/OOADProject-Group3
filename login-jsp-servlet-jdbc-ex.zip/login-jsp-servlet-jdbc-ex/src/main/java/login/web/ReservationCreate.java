package login.web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import login.bean.Reservation;
import login.database.ReservationDao;

/**
 * Servlet implementation class ReservationCreate
 */
@WebServlet("/ReservationCreate")
public class ReservationCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ReservationDao resDao;
    
	public void init() {
		resDao = new ReservationDao();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
            
			insertUser(request, response);
	           
	        } catch (SQLException ex) {
	            throw new ServletException(ex);
	        }
	}
	
	
	private void insertUser(HttpServletRequest request, HttpServletResponse response)
		    throws SQLException, IOException {
		        Integer resNum = Integer.parseInt(request.getParameter("rn"));
		        Integer tableId = Integer.parseInt(request.getParameter("tI"));
		        String custEmail = request.getParameter("ce");
		        String resDate = request.getParameter("rd");
		        Integer NumOfPeople = Integer.parseInt(request.getParameter("nop"));
		        Reservation newUser = new Reservation(resNum, tableId, custEmail, resDate, NumOfPeople);
		        resDao.insertUser(newUser);
		        response.sendRedirect("./ReservationList.jsp");
		    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
