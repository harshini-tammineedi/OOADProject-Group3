package login.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login.bean.LoginBean;
import login.bean.Order;
import login.database.OrderDao;

/**
 * Servlet implementation class OrderEdit
 */
@WebServlet("/OrderEdit")
public class OrderEdit extends HttpServlet {
	private static final long serialVersionUID = 1L;
private OrderDao empDao;
    
	public void init() {
		empDao = new OrderDao();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			updateUser(request, response);
         
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
	}
	
	private void updateUser(HttpServletRequest request, HttpServletResponse response)
		    throws SQLException, IOException {
        
		Integer ordernumber = Integer.parseInt(request.getParameter("on"));
        Integer reservationnumber = Integer.parseInt(request.getParameter("rn"));
        Integer tableid = Integer.parseInt(request.getParameter("ti"));
        String item = request.getParameter("it");
        Integer quantity = Integer.parseInt(request.getParameter("qu"));
        String status = request.getParameter("st");
        Order newUser = new Order(ordernumber, reservationnumber, tableid, item, quantity, status);
		        System.out.println("customer--"+newUser);
		        empDao.updateUser(newUser);
		        
		        response.sendRedirect("./OrdersList.jsp");
		    }
	


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
