package login.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login.database.DatabaseConnection;

/**
 * Servlet implementation class GetEmployees
 */
@WebServlet("/GetEmployees")
public class GetEmployees extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetEmployees() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				PrintWriter out = response.getWriter();  
		        response.setContentType("text/html");  
		        //String empid = request.getParameter ("emailId");
		        out.println("<html><body>");  
		        try 
		        {  
		        	Class.forName("com.mysql.cj.jdbc.Driver"); 
		            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/RMS?useSSL=false&serverTimezone=UTC", "root", "Root@123");  
		        	//Connection con = DatabaseConnection.initializeDatabase();
		        	
		            PreparedStatement ps = con.prepareStatement ("select * from Employee");
		            //ps.setString (1, empid);
		            
		            out.print("<form action=\"./AddEmployee\" method=\"post\">");
		            out.print("<p>First Name:</p>");
		            out.print("<input type=\"text\" name=\"firstname\"/>");
		            out.print("<br/>");
		            out.print("<p>Username:</p>");
		            out.print("<input type=\"text\" name=\"username\"/>");
		            out.print("<br/>");
		            out.print("<p>Password:</p>");
		            out.print("<input type=\"text\" name=\"password\"/>");
		            out.print("<br/><br/><br/>");
		            out.print("<input type=\"submit\"/>");
		            out.print("</form>");
		            
		            out.print ("<table width=50% border=1>");
		            out.print ("<caption>Employee Details:</caption>");
		            
		            ResultSet rs = ps.executeQuery ();
		            
		            /* Printing column names */
		            out.print ("</br></br>");
		            ResultSetMetaData rsmd = rs.getMetaData ();
		            int total = rsmd.getColumnCount ();
		            out.print ("<tr>");
		            for (int i = 1; i <= total; i++)
		         {
		             out.print ("<th>" + rsmd.getColumnName (i) + "</th>");
		         }
		            out.print ("</tr>");
		            
		            /* Printing result */
		            while (rs.next ())
		         {
		             out.print ("<tr><td>" + rs.getString (1) + "</td><td>" +  rs.getString (2) + " </td><td>" + rs.getString (3) + "</td></tr>");
		         }
		            out.print ("</table>");
		            out.println("</table>");  
		            out.println("</html></body>");  
		            con.close();  
		           }  
		            catch (Exception e) 
		           {  
		            out.println("error");  
		           } 
		
	}

	

}
