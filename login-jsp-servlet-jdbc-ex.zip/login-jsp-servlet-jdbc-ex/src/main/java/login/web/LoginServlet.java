package login.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import login.bean.LoginBean;
import login.database.LoginDao;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private LoginDao loginDao;

    public void init() {
        loginDao = new LoginDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

    	System.out.println("Login email---"+request.getParameter("email"));
    	System.out.println("Login pass---"+request.getParameter("password"));
        String username = request.getParameter("email");
        String password = request.getParameter("password");
        LoginBean loginBean = new LoginBean();
        loginBean.setUsername(username);
        loginBean.setPassword(password);

        try {
            if (loginDao.validate(loginBean)) {
            	String role = loginDao.getEmployeeRole(loginBean);
            	//System.out.println("role in Servlet--"+role);
            	if(role.equalsIgnoreCase("Manager")) {
            		//System.out.println("Hi...");
            		response.sendRedirect("Dashboard.jsp");
            	}
            	else if(role.equalsIgnoreCase("Chef")) {
            		response.sendRedirect("chef-index.html");
            	}
            	else if(role.equalsIgnoreCase("Waiter")) {
            		response.sendRedirect("waiterindex.jsp");
            	}
            	else {
                    System.out.println("Employee must have a valid role in the system");
            	}
                
            } else {
                HttpSession session = request.getSession();
                //session.setAttribute("user", email);
                //response.sendRedirect("login.jsp");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}