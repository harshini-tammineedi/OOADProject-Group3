package login.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import java.sql.SQLException;
import java.util.List;

import login.bean.Customer;
import login.database.CustomerDao;
/**
 * Servlet implementation class CustomerServlet
 */
@WebServlet("/customer")
public class CustomerS extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CustomerDao customerDao;
       
	public void init() {
		customerDao = new CustomerDao();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//System.out.println("Customer Servlet");
		
		// TODO Auto-generated method stub
		String action = request.getServletPath();
		//System.out.println("action---"+action);
		
		try {
          //  if (action.equalsIgnoreCase("/delete")) {
               
                  deleteUser(request, response);
                    
           /*     case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateUser(request, response);
                    break; */
               
         //  }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
	}
		
		/*private void listUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
			        List < Customer > listUser = customerDao.selectAllUsers();
			        request.setAttribute("listUser", listUser);
			        RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
			        dispatcher.forward(request, response);
			    }

			    private void showNewForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			        RequestDispatcher dispatcher = request.getRequestDispatcher("user-form.jsp");
			        dispatcher.forward(request, response);
			    }

			    private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
			        int id = Integer.parseInt(request.getParameter("id"));
			        Customer existingUser = customerDao.selectUser(id);
			        RequestDispatcher dispatcher = request.getRequestDispatcher("user-form.jsp");
			        request.setAttribute("user", existingUser);
			        dispatcher.forward(request, response);

			    }

			    private void insertUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
			        String name = request.getParameter("name");
			        String email = request.getParameter("email");
			        String country = request.getParameter("country");
			        Customer newUser = new Customer(name, email, country);
			        customerDao.insertUser(newUser);
			        response.sendRedirect("list");
			    }

			    private void updateUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
			        int id = Integer.parseInt(request.getParameter("id"));
			        String name = request.getParameter("name");
			        String email = request.getParameter("email");
			        String country = request.getParameter("country");

			        Customer book = new Customer(id, name, email, country);
			        customerDao.updateUser(book);
			        response.sendRedirect("list");
			    }*/

			    private void deleteUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
			        String email = request.getParameter("id");
			        System.out.println("Email---"+email);
			        customerDao.deleteUser(email);
			      //  response.sendRedirect("list");

			    }
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
