package login.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import java.sql.SQLException;
import java.util.List;

import login.bean.Customer;
import login.database.CustomerDao;
/**
 * Servlet implementation class CustomerServlet
 */
@WebServlet("/customerDelete")
public class CustomerDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CustomerDao customerDao;
       
	public void init() {
		customerDao = new CustomerDao();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("Customer Servlet");
		
		// TODO Auto-generated method stub
		String action = request.getServletPath();
		System.out.println("action---"+action);
		
		try {
          //  if (action.equalsIgnoreCase("/delete")) {
               
                  deleteUser(request, response);
                    
           /*     case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateUser(request, response);
                    break; */
               
         //  }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
	}
		

			    private void deleteUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
			        String email = request.getParameter("id");
			        System.out.println("Email---"+email);
			        customerDao.deleteUser(email);
			        response.sendRedirect("./CustomerList.jsp");

			    }
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

