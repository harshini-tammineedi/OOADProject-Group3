package login.web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login.bean.Customer;
import login.database.CustomerDao;

/**
 * Servlet implementation class CustomerCreate
 */
@WebServlet("/CustomerCreate")
public class CustomerCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CustomerDao customerDao;
       
	public void init() {
		customerDao = new CustomerDao();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
	               
			insertUser(request, response);
	           
	        } catch (SQLException ex) {
	            throw new ServletException(ex);
	        }
		
		System.out.println(request.getParameterValues("fn"));
        System.out.println(request.getParameterValues("ln"));
        System.out.println(request.getParameterValues("em"));
        System.out.println(request.getParameterValues("ph"));
        
        
		
	}
	
	private void insertUser(HttpServletRequest request, HttpServletResponse response)
		    throws SQLException, IOException {
		        String firstname = request.getParameter("fn");
		        String lastname = request.getParameter("ln");
		        String email = request.getParameter("em");
		        String phone = request.getParameter("ph");
		        Customer newUser = new Customer(firstname, lastname, email, phone);
		        customerDao.insertUser(newUser);
		        response.sendRedirect("./CustomerList.jsp");
		    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
