package login.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import java.sql.SQLException;
import java.util.List;

import login.bean.Customer;
import login.database.CustomerDao;
/**
 * Servlet implementation class CustomerServlet
 */
@WebServlet("/customerEdit")
public class CustomerEdit extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CustomerDao customerDao;
       
	public void init() {
		customerDao = new CustomerDao();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
               
			System.out.println("From doGet Customer Edit classsss");
			System.out.println(request.getParameter("fn"));
	        System.out.println(request.getParameter("ln"));
	        System.out.println(request.getParameter("em"));
	        System.out.println(request.getParameter("ph"));
			updateUser(request, response);
         
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
	}
		
	private void updateUser(HttpServletRequest request, HttpServletResponse response)
		    throws SQLException, IOException {
		
		System.out.println("From doGet Customer Edit classsss");
		System.out.println(request.getParameter("fn"));
        System.out.println(request.getParameter("ln"));
        System.out.println(request.getParameter("em"));
        System.out.println(request.getParameter("ph"));
        
		String firstname = request.getParameter("fn");
        String lastname = request.getParameter("ln");
        String email = request.getParameter("em");
        String phone = request.getParameter("ph");

		        Customer book = new Customer(firstname, lastname, email, phone);
		        System.out.println("customer--"+book);
		        customerDao.updateUser(book);
		        
		        response.sendRedirect("./CustomerList.jsp");
		    }
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	/*public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("From doPost Customer Edit classsss");
		System.out.println(request.getParameter("fname"));
        System.out.println(request.getParameter("lname"));
        System.out.println(request.getParameter("email"));
        System.out.println(request.getParameter("country"));
		doGet(request, response);
	}*/

}
