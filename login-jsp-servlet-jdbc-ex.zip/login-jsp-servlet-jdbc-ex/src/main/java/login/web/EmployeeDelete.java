package login.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import java.sql.SQLException;
import java.util.List;

import login.bean.LoginBean;
import login.database.EmployeeDao;
/**
 * Servlet implementation class CustomerServlet
 */
@WebServlet("/employeeDelete")
public class EmployeeDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeeDao empDao;
       
	public void init() {
		empDao = new EmployeeDao();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("Employee Servlet");
		
		// TODO Auto-generated method stub
		String action = request.getServletPath();
		System.out.println("action---"+action);
		
		try {
          //  if (action.equalsIgnoreCase("/delete")) {
               
                  deleteEmployee(request, response);
                    
           /*     case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateUser(request, response);
                    break; */
               
         //  }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
	}
		

			    private void deleteEmployee(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
			        String email = request.getParameter("id");
			        System.out.println("Email---"+email);
			        empDao.deleteEmp(email);
			        response.sendRedirect("./EmployeeList.jsp");

			    }
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

