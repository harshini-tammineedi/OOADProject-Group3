package login.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import java.sql.SQLException;
import java.util.List;

import login.bean.LoginBean;
import login.database.EmployeeDao;

/**
 * Servlet implementation class EmployeeCreate
 */
@WebServlet("/EmployeeCreate")
public class EmployeeCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeeDao empDao;
    
	public void init() {
		empDao = new EmployeeDao();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
            
			insertUser(request, response);
	           
	        } catch (SQLException ex) {
	            throw new ServletException(ex);
	        }
	}
	
	private void insertUser(HttpServletRequest request, HttpServletResponse response)
		    throws SQLException, IOException {
		String firstname = request.getParameter("fn");
        String lastname = request.getParameter("ln");
        String username = request.getParameter("un");
        String password = request.getParameter("pas");
        String role = request.getParameter("rol");
        LoginBean newUser = new LoginBean(firstname, lastname, username, password, role);
		        empDao.insertUser(newUser);
		        response.sendRedirect("./EmployeeList.jsp");
		    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
