package login.web;

import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
import java.sql.*; 
import javax.servlet.annotation.WebServlet;


@WebServlet("/GetTablesServlet") 
public class GetTablesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public GetTablesServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();  
        response.setContentType("text/html");  
        String empid = request.getParameter ("emailId");
        out.println("<html><body>");  
        try 
        {  
        	Class.forName("com.mysql.jdbc.Driver"); 
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/RMS?useSSL=false&serverTimezone=UTC", "root", "Root@123");  
        
            PreparedStatement ps = con.prepareStatement ("select * from Employee where username=?");
            ps.setString (1, empid);
            
            out.print ("<table width=50% border=1>");
            out.print ("<caption>Employee Details:</caption>");
            
            ResultSet rs = ps.executeQuery ();
            
            /* Printing column names */
            out.print ("</br></br>");
            ResultSetMetaData rsmd = rs.getMetaData ();
            int total = rsmd.getColumnCount ();
            out.print ("<tr>");
            for (int i = 1; i <= total; i++)
         {
             out.print ("<th>" + rsmd.getColumnName (i) + "</th>");
         }
            out.print ("</tr>");
            
            /* Printing result */
            while (rs.next ())
         {
             out.print ("<tr><td>" + rs.getString (1) + "</td><td>" +  rs.getString (2) + " </td><td>" + rs.getInt (3) + "</td></tr>");
         }
            out.print ("</table>");
            out.println("</table>");  
            out.println("</html></body>");  
            con.close();  
           }  
            catch (Exception e) 
           {  
            out.println("error");  
           } 
	}

}
