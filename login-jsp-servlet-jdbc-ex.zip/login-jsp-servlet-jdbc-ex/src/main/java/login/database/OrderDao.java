package login.database;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login.bean.Customer;
import login.bean.LoginBean;
import login.bean.Order;
import login.bean.Reservation;

public class OrderDao {
	
	private String jdbcURL = "jdbc:mysql://localhost:3306/RMS?useSSL=false&serverTimezone=UTC";
    private String jdbcUsername = "root";
    private String jdbcPassword = "Root@123";

    private static final String INSERT_USERS_SQL = "INSERT INTO RMS.Order" + "(OrderNumber, ReservationNumber, TableNumber, Item, Quantity, Status) VALUES " +
        " (?, ?, ?, ?, ?, ?);";

    private static final String SELECT_USER_BY_ID = "select * from RMS.Order where OrderNumber =?";
    private static final String SELECT_ALL_USERS = "select * from Order";
    private static final String DELETE_USERS_SQL = "delete from Order where OrderNumber = ?;";
    private static final String UPDATE_USERS_SQL = "update RMS.Order set ReservationNumber = ?, TableNumber= ?, Item =?, Quantity=?, Status=?  where OrderNumber = ?;";
    
    public OrderDao() {}

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return connection;
    }
    
    public void insertUser(Order user) throws SQLException {
        System.out.println(INSERT_USERS_SQL);
        // try-with-resource statement will auto close the connection.
        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
            preparedStatement.setInt(1, user.getOrdernumber());
            preparedStatement.setInt(2, user.getReservationnumber());
            preparedStatement.setInt(3, user.getTablenumber());
            preparedStatement.setString(4, user.getItem());
            preparedStatement.setInt(5, user.getQuantity());
            preparedStatement.setString(6, user.getStatus());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }
    
    public boolean updateUser(Order user) /*throws SQLException*/ {
        boolean rowUpdated = false;
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(UPDATE_USERS_SQL);) {
            
            
        	
        	statement.setInt(1, user.getReservationnumber());
        	statement.setInt(2, user.getTablenumber());
        	statement.setString(3, user.getItem());
        	statement.setInt(4, user.getQuantity());
        	statement.setString(5, user.getStatus());
        	statement.setInt(6, user.getOrdernumber());
        	
        	

            rowUpdated = statement.executeUpdate() > 0;
            System.out.println(rowUpdated);
        } catch(SQLException e) {
        	System.out.println(e.getMessage());
        }
        return rowUpdated;
    } 
    
    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }


}
