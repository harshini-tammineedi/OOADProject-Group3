package login.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import login.bean.LoginBean;
import login.database.DatabaseConnection;

public class LoginDao {

    public boolean validate(LoginBean loginBean) throws ClassNotFoundException {
        boolean status = false;

        Class.forName("com.mysql.cj.jdbc.Driver");

        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://localhost:3306/RMS?useSSL=false&serverTimezone=UTC", "root", "Root@123");

            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection
            .prepareStatement("select * from Employee where Username = ? and Password = ? ")) {
            preparedStatement.setString(1, loginBean.getUsername());
            preparedStatement.setString(2, loginBean.getPassword());

            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            status = rs.next();

        } catch (SQLException e) {
            // process sql exception
            printSQLException(e);
        }
        return status;
    }
    
    public String getEmployeeRole(LoginBean loginBean) throws ClassNotFoundException{
    	String role = null;
    	try {
    		Connection con = DatabaseConnection.initializeDatabase();
    		
    		PreparedStatement st = con.prepareStatement("select Role from Employee where Username = ? and Password = ? LIMIT 1");
    		st.setString(1, loginBean.getUsername());
    		st.setString(2, loginBean.getPassword());
    		
    		ResultSet result = st.executeQuery();
    		System.out.println("result--"+result);
    		if(result.next()){
    		   role = result.getString(1);
    		   System.out.println("Role---"+role);
    	    }
    	} catch (SQLException e) {
            // process sql exception
            printSQLException(e);
        }
    	System.out.println("returned role--"+role);
    	return role;
    	
    }
    

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
